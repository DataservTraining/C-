// AenderungenBasis.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
#include <cstdarg>
using namespace std;

namespace seminar {
    void test() {

    }
}

inline void test(std::string name) {
    cout << name << endl;
}

int add(int a, ...) {
    va_list args;
    int summe = a;
    int zahl;
    va_start(args, a);
    do {
        zahl = va_arg(args, int);
        summe += zahl;
    } while (zahl != 0);
    va_end(args);

    return summe;
}

namespace cpp {
    void test() {
        int* werte = new int[100000];
        werte[0] = 65;

        delete [] werte;
    }
}


using namespace seminar;
using namespace cpp;





int main()
{

    int summe = add(3, 7, 45, 6, 9, 0);
    cout << "Summe: " << summe << endl;
    string n = "willi";
    ::test(n);
    string text = "Hallo Welt";
    cout << text << "zweite Zeile" << endl;

    int* a;
    a = (int*) malloc(sizeof (int));
    free (a);

    a = new int;
    *a = 20;
    cpp::test();
    cout << "Wert von *a: " << *a << endl;
    cout << "Inhalt von a: " << a << endl;
    cout << "Adresse von *a: " << a << endl;
    cout << "Adresse von a: " << &a << endl;




    delete a;

    a = NULL;


    int wert;
    cout << "Wert?" << endl;
    cin >> wert;

    cout << "eingelesen: " << wert << endl;

    seminar::test();
    cpp::test();

    int zahlen[10];
    for (int z = 0; z < 10; ++z) {
        zahlen[z] = (z + 1) * 10;
    }

    int* zeiger;
    zeiger = zahlen;

    for (int z = 0; z < 10; ++z) {
        cout << zahlen[z] << ", ";
    }
    cout << endl;

    for (int z = 0; z < 10; ++z) {
        cout << *(zahlen+z) << ", ";
    }
    cout << endl;

    for (int z = 0; z < 10; ++z) {
        cout << *(zeiger++) << ", ";
    }
    cout << endl;

    bool ok = true;  // false
}
