
#include <iostream>
#include "CRechnung.h"

int main()
{
    std::cout << "Anzahl an Rechnungsobjekten: " << guido::CRechnung::getAnzahl() << std::endl;
    guido::CRechnung rechnung1; 
    std::cout << "Anzahl an Rechnungsobjekten: " << guido::CRechnung::getAnzahl() << std::endl;
    guido::CRechnung *rechnung2 = new guido::CRechnung();
    std::cout << "Anzahl an Rechnungsobjekten: " << guido::CRechnung::getAnzahl() << std::endl;

    rechnung1.drucken();

    //(*rechnung2).setKundenname("Schulz");
    rechnung2->setKundenname("Schulz");
    rechnung2->setKundennummer(843628);
    rechnung2->setBetrag(3782.34);
    rechnung2->setDatum("21.07.2022");
    rechnung2->drucken();

    delete rechnung2;
    rechnung2 = NULL;
    std::cout << "Anzahl an Rechnungsobjekten: " << guido::CRechnung::getAnzahl() << std::endl;
    rechnung1.setBetrag (32.34);
    rechnung1.setDatum("21.02.2022");
    rechnung1.setKundenname("Meier");
    rechnung1.setKundennummer(4312331);
    rechnung1.addPosition(1, "Monitor", 2, 345.56);
    rechnung1.addPosition(2, "Drucker", 1, 1345.56);
    rechnung1.addPosition(3, "Notebook", 3, 4345.56);
    rechnung1.drucken();

    // Beispiel lokale Klasse
    class Inner {
    public:
        int test;
    };

    Inner inner;
    inner.test = 34;
    
}

