#include "CRechnung.h"

namespace guido{

	int CRechnung::anzahl = 0;
	int CRechnung::MaxAnzahlPos = 10;

	CRechnung::CRechnung() 
		: kundenname("unbekannt"), 
		kundennummer(100000), 
		betrag(0.0), 
		datum("unbekannt")
	{

		++anzahl;
		positionen = new Rechnungsposition*[MaxAnzahlPos];
		/*kundenname = "unbekannt";
		kundennummer = 100000;
		betrag = 0.0;
		datum = "unbekannt";*/
	}

	CRechnung::~CRechnung(){
		std::cout << "Destruktor" << std::endl;
		for (int i = 0; i < posIndex; ++i) {
			delete positionen[i];
		}
		delete[] positionen;

		--anzahl;
	}

	int CRechnung::getAnzahl() { return anzahl;	}
	
	void CRechnung::drucken() {
		std::cout << "Rechnungsdaten" << std::endl;
		std::cout << "Kundennummer: " << kundennummer << std::endl;
		std::cout << "Kundenname: " << kundenname << std::endl;
		std::cout << "Datum: " << datum << std::endl;
		std::cout << "Betrag: " << betrag << std::endl;
		for (int i = 0; i < posIndex; ++i) {
			positionen[i]->drucken(this);
		}
	}

	int CRechnung::getKundennummer() { return kundennummer; }
	std::string CRechnung::getKundenname() { return kundenname; }
	double CRechnung::getBetrag() { return betrag; }
	std::string CRechnung::getDatum() { return datum; }

	void CRechnung::setKundennummer(int kundennr){
		if (kundennr < 100000 || kundennr > 999999) {
			std::cout << "ung�ltiger Wert f�r Kundennummer: " << kundennr << std::endl;
			return;
		}
		kundennummer = kundennr;
	}
	void CRechnung::setKundenname(std::string Kundenn) { kundenname = Kundenn;  }
	void CRechnung::setBetrag(double betr){
		if (betr < 0) {
			std::cout << "ung�ltiger Wert f�r Betrag: " << betr << std::endl;
			return;
		}
		betrag = betr;
	}


	void CRechnung::setDatum(std::string dat) { datum = dat; }

	void CRechnung::addPosition(int positionsnummer, std::string bezeichnung, double menge, double preis)
	{
		positionen[posIndex++] = new Rechnungsposition(positionsnummer, bezeichnung, menge, preis);
	}

	// Definitionen Rechnungsposition

	CRechnung::Rechnungsposition::Rechnungsposition() : Rechnungsposition(1, "Bezeichnung", 0, 0.0) {}
	CRechnung::Rechnungsposition::Rechnungsposition(int positionsnummer, std::string bezeichnung, double menge, double preis) 
		: positionsNummer(positionsnummer), bezeichnung(bezeichnung), betrag(0)
	{
		setMenge(menge);
		setPreis(preis);
	}
	int CRechnung::Rechnungsposition::getPositionsNummer() { return positionsNummer; }
	std::string CRechnung::Rechnungsposition::getBezeichnung() { return bezeichnung; }
	double CRechnung::Rechnungsposition::getMenge() { return menge; }
	double CRechnung::Rechnungsposition::getPreis() { return preis; }
	double CRechnung::Rechnungsposition::getBetrag() { return betrag; }

	void CRechnung::Rechnungsposition::setPositionsNummer(int positionsNummer) { this->positionsNummer = positionsNummer; }
	void CRechnung::Rechnungsposition::setBezeichnung(std::string bez) { bezeichnung = bez; }
	void CRechnung::Rechnungsposition::setMenge(double m) { 
		menge = m; 
		berechneBetrag();
	}
	void CRechnung::Rechnungsposition::setPreis(double p) { 
		preis = p; 
		berechneBetrag();
	}


	void CRechnung::Rechnungsposition::berechneBetrag() { betrag = menge * preis; }
	void CRechnung::Rechnungsposition::drucken(CRechnung* rechnung) {
		std::cout << positionsNummer << "\t" << bezeichnung << "\t" << menge << "   " << preis << "   " << betrag << "     " << rechnung->kundennummer << std::endl;
	}
}
