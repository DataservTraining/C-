#pragma once
#include <iostream>
#include <string>

namespace guido {
	class CRechnung
	{

	public:
		CRechnung();
		~CRechnung();
		void drucken();
		int getKundennummer();
		std::string getKundenname();
		double getBetrag();
		std::string getDatum();
		static int getAnzahl();

		void setKundennummer(int kundennummer);
		void setKundenname(std::string Kundenname);
		void setBetrag(double betrag);
		void setDatum(std::string datum);
		void addPosition(int positionsnummer, std::string bezeichnung, double menge, double preis);

		class Rechnungsposition {
		public:
			Rechnungsposition();
			Rechnungsposition(int positionsnummer, std::string bezeichnung, double menge, double preis);
			int getPositionsNummer();
			std::string getBezeichnung();
			double getMenge();
			double getPreis();
			double getBetrag();

			void setPositionsNummer(int positionsNummer);
			void setBezeichnung(std::string bezeichnung);
			void setMenge(double menge);
			void setPreis(double preis);
			void drucken(CRechnung* rechnung);

		private:
			int positionsNummer = 0;
			std::string bezeichnung;
			double menge = 0.0;
			double preis = 0.0;
			double betrag = 0.0;

			void berechneBetrag();
			
		};
	private:
		
		int kundennummer = 0;
		std::string  kundenname;
		double betrag = 0.0;
		std::string datum;
		int posIndex = 0;
		Rechnungsposition** positionen;

		static int anzahl;
		static int MaxAnzahlPos;

	};

}

