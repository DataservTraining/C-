// Uebungen_4.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
using namespace std;

int vorgabe();
int noten();
int ueberladen();
int referenzen();
int refVariable();
int refFunktion();

int main()
{
   /* cout << "Uebung 1" << endl;
    vorgabe();
    cout << "Uebung 2" << endl;
    noten();
    cout << "Uebung 3" << endl;
    ueberladen();
    cout << "Uebung 4" << endl;
    referenzen();
    cout << "Uebung 5" << endl;
    refVariable();*/
    cout << "Uebung 6" << endl;
    refFunktion();
   
}

