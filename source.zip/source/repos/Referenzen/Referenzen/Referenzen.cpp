// Referenzen.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
using namespace std;

void myswap(int a, int b) {
    cout << "a: " << a << "\tb:_" << b << endl;
    int temp = a;
    a = b;
    b = temp;
    cout << "a: " << a << "\tb:_" << b << endl;
}

void myswap(int *a, int *b) {
    cout << "a: " << *a << "\tb:_" << *b << endl;
    int temp = *a;
    *a = *b;
    *b = temp;
    cout << "a: " << *a << "\tb:_" << *b << endl;
}

int& myswap(int &a, int &b) {
    cout << "a: " << a << "\tb:_" << b << endl;
    int temp = a;
    a = b;
    b = temp;
    cout << "a: " << a << "\tb:_" << b << endl;
    return temp;
}


int main()
{
    int x = 9, y = 3;
    int& ref = x;
    int z = 9;

    cout << "x: " << x << "\ty:_" << y << endl;
    int ruechgabe = myswap(x, y);
    cout << ruechgabe << endl;
    cout << "x: " << x << "\ty:_" << y << endl;
    ref = 6;
    cout << "x: " << x << "\ty:_" << y << endl;
}

