#pragma once
class CZahl
{
public:
	CZahl();
	explicit CZahl(int v);
	int getValue();
	void test(int w) const;
	void print();

private:
	mutable int value;
	/*int value2;
	int value3;*/
};

