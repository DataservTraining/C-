#include "CZahl.h"
#include <iostream>

CZahl::CZahl() : value(0) {}
explicit CZahl::CZahl(int v) : value(v) {}
int CZahl::getValue() { return value; }
void CZahl::test(int w)  const {
	value = w;
	//std::cout << value2 << std::endl;
	//value3 = w;
}

void CZahl::print() {
	std::cout << value << std::endl;
}