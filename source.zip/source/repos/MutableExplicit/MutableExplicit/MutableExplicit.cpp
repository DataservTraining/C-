
#include <iostream>
#include "CZahl.h"

int main()
{
    CZahl zahl1(23);
   // CZahl zahl2 = 45;
    //CZahl zahl2{ 45 };
    int wert{ 34 };
    zahl1.print();
    //zahl2.print();

    std::cout << wert << std::endl;
}
