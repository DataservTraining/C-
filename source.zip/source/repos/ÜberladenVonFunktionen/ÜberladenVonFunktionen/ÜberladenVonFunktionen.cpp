// ÜberladenVonFunktionen.cpp : Diese Datei enthält die Funktion "main". Hier beginnt und endet die Ausführung des Programms.
//

#include <iostream>
using namespace std;

int add(int a, int b) {
    return a + b;
}

double add(double a, double b) {
    return a + b;
}

double add(int a, double b) {
    return a + b;
}

double add(double a, int b) {
    return a + b;
}

string add(string a, string b) {
    return a + b;
}

int main()
{
    int iX = 3, iY = 7, iErg;
    iErg = add(iX, iY);
    cout << iErg << endl;

    double dX = 3.6, dY = 7.2, dErg;
    dErg = add(dX, dY);
    cout << dErg << endl;

    dErg = add((double)iX, dY);
    dErg = add(dX, (double)iY);

    string sX = "Hallo", sY = " Welt", sErg;
    sErg = add(sX, sY);
    cout << sErg << endl;
}

