#include "CKonto.h"
#include <iostream>
using namespace std;

int CKonto::anzahl = 0; // Initialisierung

double Inventur(const CKonto &konto)
{
    return konto.Kontostand;
}


CKonto::CKonto()  // Standard-Konstruktor
{
    Kontostand = 0;
    Dispo = 0;
    ++anzahl;
}

//CKonto::CKonto(const CKonto& konto) {
//    this->Kontostand = konto.Kontostand;
//    this->Dispo = konto.Dispo;
//    ++anzahl;
//}

CKonto::~CKonto()  // Standard-Konstruktor
{
    --anzahl;
}

double CKonto::GetKonto()
{
    return Kontostand;
}
void CKonto::SetKonto(double Betrag)
{
    Kontostand = Betrag;
}
void CKonto::Einzahlen(double Betrag)
{
    Kontostand += Betrag;
}
void CKonto::Auszahlen(double Betrag)
{
    if (Kontostand + Dispo - Betrag >= 0)
        Kontostand -= Betrag;
    else
        cout << "Auszahlung nicht moeglich!" << endl;
}
void CKonto::SetDispo(double Volumen)
{
    Dispo = Volumen;
}
void CKonto::Information()
{
    cout << "======= Kontoinformation ==========" << endl;
    cout << "=                                 =" << endl;
    cout << "= Dispositionskredit: " << Dispo << " EUR" << endl;
    cout << "=                                 =" << endl;
    cout << "= Kontostand: " << Kontostand << " EUR" << endl;
    cout << "=                                 =" << endl;
    cout << "= Verfuegbarer Betrag: " << Kontostand + Dispo << " EUR" << endl;
    cout << "=                                 =" << endl;
    cout << "===================================" << endl;
}

int& CKonto::Gibanzahl()
{
  return anzahl;
}