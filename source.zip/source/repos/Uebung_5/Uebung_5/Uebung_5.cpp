

#include <iostream>
int saldo();
int kontofuehrung();
int kontoanzahl();
int instanz();
int heirat();
int constmute();

int main()
{
	/*std::cout << "Uebung 1:" << std::endl;
	kontofuehrung();
	std::cout << "Uebung 2:" << std::endl;
	heirat();
	std::cout << "Uebung 3:" << std::endl;
	saldo();*/
	std::cout << "Uebung 4:" << std::endl;
	kontoanzahl();
	/*std::cout << "Uebung 5:" << std::endl;
	instanz();
	std::cout << "Uebung 6:" << std::endl;
	constmute();
	*/
}
