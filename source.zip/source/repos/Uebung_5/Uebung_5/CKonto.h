#pragma once

class CKonto
{
private:
    double Kontostand;
    double Dispo;
    static int anzahl;

public:
    CKonto();
    //CKonto(const CKonto &konto);
    ~CKonto();
    void SetKonto(double Betrag);
    double GetKonto();
    void Einzahlen(double Betrag);
    void Auszahlen(double Betrag);
    void SetDispo(double Volumen);
    void Information();
    friend double Inventur(const CKonto &konto);
    static int& Gibanzahl();
};
